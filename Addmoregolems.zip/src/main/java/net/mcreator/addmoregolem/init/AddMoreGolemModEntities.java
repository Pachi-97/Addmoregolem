
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.addmoregolem.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.addmoregolem.entity.WoodgolemEntity;
import net.mcreator.addmoregolem.entity.GoldengolemEntity;
import net.mcreator.addmoregolem.entity.DiamondgolemEntity;
import net.mcreator.addmoregolem.AddMoreGolemMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AddMoreGolemModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AddMoreGolemMod.MODID);
	public static final RegistryObject<EntityType<DiamondgolemEntity>> DIAMONDGOLEM = register("diamondgolem",
			EntityType.Builder.<DiamondgolemEntity>of(DiamondgolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DiamondgolemEntity::new)

					.sized(1f, 3f));
	public static final RegistryObject<EntityType<GoldengolemEntity>> GOLDENGOLEM = register("goldengolem",
			EntityType.Builder.<GoldengolemEntity>of(GoldengolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GoldengolemEntity::new)

					.sized(1f, 2.5f));
	public static final RegistryObject<EntityType<WoodgolemEntity>> WOODGOLEM = register("woodgolem",
			EntityType.Builder.<WoodgolemEntity>of(WoodgolemEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WoodgolemEntity::new)

					.sized(1f, 2f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DiamondgolemEntity.init();
			GoldengolemEntity.init();
			WoodgolemEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DIAMONDGOLEM.get(), DiamondgolemEntity.createAttributes().build());
		event.put(GOLDENGOLEM.get(), GoldengolemEntity.createAttributes().build());
		event.put(WOODGOLEM.get(), WoodgolemEntity.createAttributes().build());
	}
}
