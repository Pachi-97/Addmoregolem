
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.addmoregolem.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.addmoregolem.AddMoreGolemMod;

public class AddMoreGolemModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AddMoreGolemMod.MODID);
	public static final RegistryObject<Item> DIAMONDGOLEM_SPAWN_EGG = REGISTRY.register("diamondgolem_spawn_egg",
			() -> new ForgeSpawnEggItem(AddMoreGolemModEntities.DIAMONDGOLEM, -16737895, -16724788, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> GOLDENGOLEM_SPAWN_EGG = REGISTRY.register("goldengolem_spawn_egg", () -> new ForgeSpawnEggItem(AddMoreGolemModEntities.GOLDENGOLEM, -6711040, -205, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> WOODGOLEM_SPAWN_EGG = REGISTRY.register("woodgolem_spawn_egg", () -> new ForgeSpawnEggItem(AddMoreGolemModEntities.WOODGOLEM, -8897536, -13408768, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
}
