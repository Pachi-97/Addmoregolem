
package net.mcreator.addmoregolem.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.addmoregolem.entity.WoodgolemEntity;
import net.mcreator.addmoregolem.client.model.Modeliron_golem;

public class WoodgolemRenderer extends MobRenderer<WoodgolemEntity, Modeliron_golem<WoodgolemEntity>> {
	public WoodgolemRenderer(EntityRendererProvider.Context context) {
		super(context, new Modeliron_golem(context.bakeLayer(Modeliron_golem.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(WoodgolemEntity entity) {
		return new ResourceLocation("add_more_golem:textures/entities/woodgolem.png");
	}
}
