
package net.mcreator.addmoregolem.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.addmoregolem.entity.GoldengolemEntity;
import net.mcreator.addmoregolem.client.model.Modeliron_golem;

public class GoldengolemRenderer extends MobRenderer<GoldengolemEntity, Modeliron_golem<GoldengolemEntity>> {
	public GoldengolemRenderer(EntityRendererProvider.Context context) {
		super(context, new Modeliron_golem(context.bakeLayer(Modeliron_golem.LAYER_LOCATION)), 1f);
	}

	@Override
	public ResourceLocation getTextureLocation(GoldengolemEntity entity) {
		return new ResourceLocation("add_more_golem:textures/entities/golden_golem.png");
	}
}
